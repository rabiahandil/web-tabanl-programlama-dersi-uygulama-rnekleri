
import { initializeApp } from "firebase/app";
import { 
  getFirestore, 
  collection, 
  onSnapshot, 
  doc, 
  setDoc, 
  deleteDoc, 
  query, 
  orderBy,
  addDoc,
  serverTimestamp
} from "firebase/firestore";
import { Note, Folder } from '../types';

const firebaseConfig = { 
  apiKey: "AIzaSyD9yfJUW8N7hCNHyesf3_ihSwRmzIPgrys", 
  authDomain: "not-projesi-f1cb4.firebaseapp.com", 
  projectId: "not-projesi-f1cb4", 
  storageBucket: "not-projesi-f1cb4.firebasestorage.app", 
  messagingSenderId: "700448786254", 
  appId: "1:700448786254:web:6b3f6673ad4efcd036c01f", 
  measurementId: "G-MEWZDJVR35" 
};

// Firebase'i başlat
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

class StorageService {
  private notesColl = collection(db, "notes");
  private foldersColl = collection(db, "folders");

  // Notları gerçek zamanlı dinle
  onNotesChange(callback: (notes: Note[]) => void) {
    const q = query(this.notesColl, orderBy("updatedAt", "desc"));
    return onSnapshot(q, (snapshot) => {
      const notes = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Note[];
      
      // Eğer veritabanı boşsa varsayılanları ekle (ilk çalıştırma için)
      if (notes.length === 0 && snapshot.metadata.fromCache === false) {
        this.initializeDefaultNotes();
      }
      
      callback(notes);
    });
  }

  // Klasörleri gerçek zamanlı dinle
  onFoldersChange(callback: (folders: Folder[]) => void) {
    return onSnapshot(this.foldersColl, (snapshot) => {
      let folders = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Folder[];

      if (folders.length === 0 && snapshot.metadata.fromCache === false) {
        this.initializeDefaultFolders();
      }
      
      // Sabit klasörleri (Tüm Notlar, Favoriler) her zaman en üstte tut
      const staticFolders = [
        { id: 'all', name: 'Tüm Notlar', icon: '📝', color: 'bg-blue-500' },
        { id: 'fav', name: 'Favoriler', icon: '⭐', color: 'bg-yellow-500' }
      ];
      
      // Mevcut klasörlerde all veya fav yoksa ekle (opsiyonel mantık)
      const dynamicFolders = folders.filter(f => f.id !== 'all' && f.id !== 'fav');
      callback([...staticFolders, ...dynamicFolders]);
    });
  }

  async saveNote(note: Note) {
    const noteRef = doc(db, "notes", note.id);
    const data = { ...note, updatedAt: Date.now() };
    await setDoc(noteRef, data, { merge: true });
  }

  async deleteNote(id: string) {
    await deleteDoc(doc(db, "notes", id));
  }

  async saveFolder(folder: Folder) {
    await addDoc(this.foldersColl, folder);
  }

  private async initializeDefaultNotes() {
    const defaults = [
      {
        id: 'welcome-1',
        title: 'Hoş Geldin Kahraman!',
        content: 'Bu senin yeni not defterin. Her şey bulut üzerinde ve gerçek zamanlı!',
        folderId: 'all',
        color: 'bg-yellow-200',
        isFavorite: true,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        position: { x: 0, y: 0 }
      }
    ];
    for (const n of defaults) {
      await this.saveNote(n);
    }
  }

  private async initializeDefaultFolders() {
    // Statik klasörler kod içinde tanımlı, buraya özel klasörler eklenebilir
    const extra = { name: 'Fikirler', icon: '💡', color: 'bg-purple-500' };
    await this.saveFolder(extra as Folder);
  }
}

export const storage = new StorageService();
