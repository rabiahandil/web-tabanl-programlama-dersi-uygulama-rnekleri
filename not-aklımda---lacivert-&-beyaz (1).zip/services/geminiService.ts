
import { GoogleGenAI } from "@google/genai";

export const summarizeNote = async (title: string, content: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Lütfen aşağıdaki notu kısaca özetle ve 3 anahtar kelime ekle. 
      Dil: Türkçe. 
      Başlık: ${title}
      İçerik: ${content}`,
      config: {
        temperature: 0.7,
        topK: 40,
        topP: 0.95,
      }
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "AI şu an meşgul, daha sonra tekrar dene!";
  }
};
