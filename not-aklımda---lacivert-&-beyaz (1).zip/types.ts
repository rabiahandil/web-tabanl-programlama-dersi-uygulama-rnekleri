
export interface Note {
  id: string;
  title: string;
  content: string;
  folderId: string;
  color: string;
  isFavorite: boolean;
  createdAt: number;
  updatedAt: number;
  position: { x: number; y: number };
}

export interface Folder {
  id: string;
  name: string;
  icon: string;
  color: string;
}

export enum AppTheme {
  NAVY = '#000080',
  WHITE = '#FFFFFF',
  ACCENT = '#FFD700'
}
