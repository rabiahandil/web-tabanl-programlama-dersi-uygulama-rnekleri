
import React, { useState, useEffect, useMemo } from 'react';
import Sidebar from './components/Sidebar';
import NoteCard from './components/NoteCard';
import NoteEditor from './components/NoteEditor';
import { Note, Folder } from './types';
import { storage } from './services/storageService';
import { COLORS } from './constants';

const App: React.FC = () => {
  const [notes, setNotes] = useState<Note[]>([]);
  const [folders, setFolders] = useState<Folder[]>([]);
  const [activeFolderId, setActiveFolderId] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [editingNote, setEditingNote] = useState<Note | null>(null);

  useEffect(() => {
    const unsubNotes = storage.onNotesChange(setNotes);
    const unsubFolders = storage.onFoldersChange(setFolders);
    return () => {
      unsubNotes();
      unsubFolders();
    };
  }, []);

  const filteredNotes = useMemo(() => {
    let list = notes;
    if (activeFolderId === 'fav') {
      list = list.filter(n => n.isFavorite);
    } else if (activeFolderId !== 'all') {
      list = list.filter(n => n.folderId === activeFolderId);
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter(n => 
        n.title.toLowerCase().includes(q) || 
        n.content.toLowerCase().includes(q)
      );
    }

    return list.sort((a, b) => b.updatedAt - a.updatedAt);
  }, [notes, activeFolderId, searchQuery]);

  const handleCreateNote = () => {
    const newNote: Note = {
      id: Date.now().toString(),
      title: '',
      content: '',
      folderId: activeFolderId === 'all' || activeFolderId === 'fav' ? 'all' : activeFolderId,
      color: COLORS[Math.floor(Math.random() * COLORS.length)],
      isFavorite: activeFolderId === 'fav',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      position: { x: 0, y: 0 }
    };
    storage.saveNote(newNote);
    setEditingNote(newNote);
  };

  return (
    <div className="flex h-screen bg-[#f1f5f9] text-[#000033]">
      <Sidebar 
        folders={folders} 
        notes={notes} // Sürükle-bırak için eklendi
        activeFolder={activeFolderId} 
        onSelectFolder={setActiveFolderId} 
      />

      <main className="flex-1 flex flex-col h-full overflow-hidden">
        {/* Header */}
        <header className="px-10 py-8 flex justify-between items-center gap-6">
          <div className="flex-1 max-w-2xl relative">
            <input 
              type="text"
              placeholder="Notlarda ara... (BAM! POW! ZAP!)"
              className="w-full px-6 py-4 comic-border comic-shadow-sm rounded-2xl outline-none font-bold text-lg focus:ring-4 ring-blue-400/20 bg-white"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
            />
            <span className="absolute right-6 top-1/2 -translate-y-1/2 text-2xl">🔍</span>
          </div>

          <button 
            onClick={handleCreateNote}
            className="bg-[#000033] text-white px-8 py-4 rounded-2xl comic-font text-2xl comic-shadow hover:bg-black transition-all flex items-center gap-3 active:scale-95"
          >
            <span>+</span> YENİ NOT
          </button>
        </header>

        {/* Note Grid */}
        <div className="flex-1 overflow-y-auto px-10 pb-10">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {filteredNotes.length > 0 ? (
              filteredNotes.map(note => (
                <NoteCard key={note.id} note={note} onClick={setEditingNote} />
              ))
            ) : (
              <div className="col-span-full py-20 flex flex-col items-center justify-center opacity-40">
                <span className="text-8xl mb-6">🏜️</span>
                <p className="text-2xl font-black comic-font uppercase italic">Burada henüz macera yok!</p>
                <p className="font-bold mt-2">Hemen bir not ekleyerek başla.</p>
              </div>
            )}
          </div>
        </div>
      </main>

      {editingNote && (
        <NoteEditor 
          note={editingNote} 
          onClose={() => setEditingNote(null)} 
        />
      )}

      {/* Comic Accent Stickers */}
      <div className="fixed bottom-4 right-4 pointer-events-none select-none z-0 opacity-50">
        <div className="comic-font text-white bg-red-600 px-4 py-2 text-3xl comic-border comic-shadow -rotate-12 mb-2">WOW!</div>
        <div className="comic-font text-white bg-blue-600 px-4 py-2 text-2xl comic-border comic-shadow rotate-6">IDEAS!</div>
      </div>
    </div>
  );
};

export default App;
