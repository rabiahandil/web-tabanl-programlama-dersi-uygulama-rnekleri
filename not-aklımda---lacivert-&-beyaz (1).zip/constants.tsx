
export const COLORS = [
  'bg-white',
  'bg-yellow-200',
  'bg-blue-200',
  'bg-green-200',
  'bg-pink-200',
  'bg-purple-200',
  'bg-orange-200'
];

export const FOLDER_ICONS = ['📁', '🏷️', '🏠', '💼', '🎓', '💡', '🎨', '🚀'];
