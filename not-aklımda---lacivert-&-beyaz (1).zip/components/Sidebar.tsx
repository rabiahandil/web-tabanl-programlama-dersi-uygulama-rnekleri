
import React, { useState } from 'react';
import { Folder, Note } from '../types';
import { FOLDER_ICONS } from '../constants';
import { storage } from '../services/storageService';

interface SidebarProps {
  folders: Folder[];
  notes: Note[]; // Sürüklenen notu bulmak için eklendi
  activeFolder: string;
  onSelectFolder: (id: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ folders, notes, activeFolder, onSelectFolder }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');
  const [dragOverId, setDragOverId] = useState<string | null>(null);

  const handleAddFolder = () => {
    if (!newFolderName.trim()) return;
    const newFolder: Folder = {
      id: Date.now().toString(),
      name: newFolderName,
      icon: FOLDER_ICONS[Math.floor(Math.random() * FOLDER_ICONS.length)],
      color: 'bg-blue-400'
    };
    storage.saveFolder(newFolder);
    setNewFolderName('');
    setIsAdding(false);
  };

  const handleDragOver = (e: React.DragEvent, folderId: string) => {
    e.preventDefault(); // Drop'a izin ver
    if (dragOverId !== folderId) setDragOverId(folderId);
  };

  const handleDragLeave = () => {
    setDragOverId(null);
  };

  const handleDrop = (e: React.DragEvent, folderId: string) => {
    e.preventDefault();
    setDragOverId(null);
    const noteId = e.dataTransfer.getData('noteId');
    
    // Notu prop olarak gelen listeden bul (Firestore'dan gelen güncel liste)
    const note = notes.find(n => n.id === noteId);

    if (note) {
      const updatedNote = { ...note };
      
      if (folderId === 'fav') {
        // Favorilere bırakıldıysa favori yap, klasörünü değiştirme (veya varsayılana çek)
        updatedNote.isFavorite = true;
      } else if (folderId === 'all') {
        // Tüm notlara bırakıldıysa klasörsüz yap
        updatedNote.folderId = 'all';
      } else {
        // Belirli bir klasöre bırakıldıysa o klasöre taşı
        updatedNote.folderId = folderId;
        // Eğer bir klasöre taşınıyorsa o klasörün favori klasörü olmadığını biliyoruz
      }

      storage.saveNote(updatedNote);
      console.log(`POW! Not ${noteId}, ${folderId} klasörüne uçtu!`);
    }
  };

  return (
    <div className="w-72 bg-white comic-border h-full flex flex-col p-6 overflow-y-auto shrink-0 z-10">
      <div className="flex items-center gap-2 mb-8">
        <div className="w-12 h-12 bg-[#000033] rounded-full flex items-center justify-center text-white text-2xl comic-shadow-sm font-black italic">
          NA
        </div>
        <h1 className="comic-font text-3xl text-[#000033]">Not Aklımda</h1>
      </div>

      <div className="flex-1 space-y-4">
        <p className="font-black text-xs uppercase tracking-widest text-slate-400 mb-2">Klasörler</p>
        {folders.map(folder => (
          <button
            key={folder.id}
            onClick={() => onSelectFolder(folder.id)}
            onDragOver={(e) => handleDragOver(e, folder.id)}
            onDragLeave={handleDragLeave}
            onDrop={(e) => handleDrop(e, folder.id)}
            className={`w-full text-left px-4 py-3 comic-border rounded-xl flex items-center gap-3 transition-all duration-200 relative ${
              activeFolder === folder.id 
                ? 'bg-[#000033] text-white comic-shadow transform translate-x-1' 
                : 'bg-white text-[#000033] hover:bg-slate-50'
            } ${dragOverId === folder.id ? 'border-dashed border-4 border-yellow-500 scale-105 bg-yellow-50 ring-4 ring-yellow-400/20' : ''}`}
          >
            <span className="text-xl">{folder.icon}</span>
            <span className="font-bold truncate">{folder.name}</span>
            {dragOverId === folder.id && (
              <div className="absolute -top-6 left-1/2 -translate-x-1/2 bg-yellow-400 text-[#000033] px-3 py-1 text-[10px] font-black comic-border rotate-3 whitespace-nowrap shadow-lg">
                BAM! BURAYA BIRAK!
              </div>
            )}
          </button>
        ))}

        {isAdding ? (
          <div className="mt-4 space-y-2 p-2 comic-border rounded-lg bg-slate-50">
            <input
              autoFocus
              className="w-full px-2 py-1 outline-none font-bold bg-transparent"
              placeholder="Klasör adı..."
              value={newFolderName}
              onChange={e => setNewFolderName(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleAddFolder()}
            />
            <div className="flex gap-2">
              <button onClick={handleAddFolder} className="flex-1 bg-green-500 text-white font-bold py-1 comic-border comic-shadow-sm text-xs">EKLE</button>
              <button onClick={() => setIsAdding(false)} className="flex-1 bg-red-400 text-white font-bold py-1 comic-border comic-shadow-sm text-xs">İPTAL</button>
            </div>
          </div>
        ) : (
          <button 
            onClick={() => setIsAdding(true)}
            className="w-full mt-4 border-2 border-dashed border-[#000033] rounded-xl py-3 font-bold text-[#000033] hover:bg-slate-50 flex items-center justify-center gap-2 transition-colors"
          >
            + Klasör Oluştur
          </button>
        )}
      </div>

      <div className="mt-auto pt-6 border-t-2 border-[#000033] border-dashed">
        <div className="flex items-center gap-3 p-3">
          <img src="https://picsum.photos/40/40" className="w-10 h-10 rounded-full comic-border" alt="user" />
          <div>
            <p className="font-black text-sm">Kullanıcı</p>
            <p className="text-xs text-slate-500">Kıdemli Maceracı</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
