
import React from 'react';
import { Note } from '../types';
import { storage } from '../services/storageService';

interface NoteCardProps {
  note: Note;
  onClick: (note: Note) => void;
}

const NoteCard: React.FC<NoteCardProps> = ({ note, onClick }) => {
  const toggleFavorite = (e: React.MouseEvent) => {
    e.stopPropagation();
    storage.saveNote({ ...note, isFavorite: !note.isFavorite });
  };

  const handleDragStart = (e: React.DragEvent) => {
    e.dataTransfer.setData('noteId', note.id);
    e.dataTransfer.effectAllowed = 'move';
    // Add a slight delay to styling so the drag image looks original
    setTimeout(() => {
      (e.target as HTMLElement).style.opacity = '0.4';
    }, 0);
  };

  const handleDragEnd = (e: React.DragEvent) => {
    (e.target as HTMLElement).style.opacity = '1';
  };

  return (
    <div 
      draggable="true"
      onDragStart={handleDragStart}
      onDragEnd={handleDragEnd}
      onClick={() => onClick(note)}
      className={`relative group cursor-grab active:cursor-grabbing p-6 comic-border comic-shadow rounded-2xl ${note.color} transition-all duration-200 hover:-rotate-1 active:scale-95 min-h-[200px] flex flex-col`}
    >
      <div className="flex justify-between items-start mb-4">
        <h3 className="font-black text-xl text-[#000033] leading-tight line-clamp-2 uppercase pointer-events-none">
          {note.title || 'Başlıksız Not'}
        </h3>
        <button 
          onClick={toggleFavorite}
          className={`text-2xl transition-transform hover:scale-125 ${note.isFavorite ? 'text-yellow-500' : 'text-slate-300'}`}
        >
          {note.isFavorite ? '★' : '☆'}
        </button>
      </div>
      
      <p className="text-[#000033] font-medium leading-relaxed flex-1 line-clamp-4 pointer-events-none">
        {note.content || 'Bir şeyler yazmak için tıkla...'}
      </p>

      <div className="mt-4 flex justify-between items-center pt-4 border-t-2 border-[#000033] border-dashed pointer-events-none">
        <span className="text-[10px] font-black uppercase text-slate-600">
          {new Date(note.updatedAt).toLocaleDateString('tr-TR')}
        </span>
        <div className="opacity-0 group-hover:opacity-100 transition-opacity">
           <span className="text-xs font-bold text-[#000033]">DÜZENLE ✎</span>
        </div>
      </div>
    </div>
  );
};

export default NoteCard;
