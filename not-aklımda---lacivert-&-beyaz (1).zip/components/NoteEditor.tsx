
import React, { useState, useEffect } from 'react';
import { Note } from '../types';
import { COLORS } from '../constants';
import { storage } from '../services/storageService';
import { summarizeNote } from '../services/geminiService';

interface NoteEditorProps {
  note: Note;
  onClose: () => void;
}

const NoteEditor: React.FC<NoteEditorProps> = ({ note, onClose }) => {
  const [editedNote, setEditedNote] = useState<Note>(note);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiResponse, setAiResponse] = useState<string | null>(null);

  useEffect(() => {
    const timeout = setTimeout(() => {
      storage.saveNote({ ...editedNote, updatedAt: Date.now() });
    }, 1000);
    return () => clearTimeout(timeout);
  }, [editedNote]);

  const handleAiSummarize = async () => {
    setAiLoading(true);
    setAiResponse(null);
    const summary = await summarizeNote(editedNote.title, editedNote.content);
    setAiResponse(summary);
    setAiLoading(false);
  };

  const handleDelete = () => {
    if (confirm('Bu notu silmek istediğine emin misin?')) {
      storage.deleteNote(editedNote.id);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 bg-[#000033]/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className={`w-full max-w-2xl comic-border comic-shadow rounded-3xl overflow-hidden flex flex-col ${editedNote.color} max-h-[90vh]`}>
        {/* Toolbar */}
        <div className="p-6 border-b-4 border-[#000033] flex justify-between items-center bg-white/50">
          <div className="flex gap-2">
            {COLORS.map(c => (
              <button 
                key={c}
                onClick={() => setEditedNote(prev => ({ ...prev, color: c }))}
                className={`w-6 h-6 rounded-full comic-border comic-shadow-sm ${c} ${editedNote.color === c ? 'ring-2 ring-black scale-110' : ''}`}
              />
            ))}
          </div>
          <div className="flex items-center gap-4">
            <button 
              onClick={handleAiSummarize}
              disabled={aiLoading}
              className="bg-purple-600 text-white font-black px-4 py-2 rounded-xl comic-border comic-shadow-sm hover:bg-purple-700 disabled:opacity-50 flex items-center gap-2"
            >
              {aiLoading ? 'Düşünüyor...' : '✨ AI Özet'}
            </button>
            <button 
              onClick={handleDelete}
              className="bg-red-500 text-white font-black px-4 py-2 rounded-xl comic-border comic-shadow-sm hover:bg-red-600"
            >
              SİL
            </button>
            <button 
              onClick={onClose}
              className="bg-[#000033] text-white font-black px-4 py-2 rounded-xl comic-border comic-shadow-sm hover:bg-black"
            >
              KAPAT
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-8 flex-1 overflow-y-auto space-y-6">
          <input 
            className="w-full bg-transparent text-4xl font-black comic-font outline-none placeholder-[#000033]/30 text-[#000033]"
            placeholder="HARİKA BİR BAŞLIK..."
            value={editedNote.title}
            onChange={e => setEditedNote(prev => ({ ...prev, title: e.target.value }))}
          />
          <textarea 
            className="w-full bg-transparent text-xl font-bold outline-none placeholder-[#000033]/30 min-h-[300px] resize-none leading-relaxed"
            placeholder="Bugün neler oldu? Notlarını buraya dök..."
            value={editedNote.content}
            onChange={e => setEditedNote(prev => ({ ...prev, content: e.target.value }))}
          />

          {aiResponse && (
            <div className="bg-white/80 p-6 comic-border rounded-2xl mt-8">
               <h4 className="font-black text-sm uppercase text-purple-700 mb-2 italic">AI Zekası Diyor Ki:</h4>
               <p className="font-bold text-[#000033] italic">{aiResponse}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default NoteEditor;
